//
//  ViewController.m
//  Test
//
//  Created by MAC 1 on 14/04/16.
//  Copyright © 2016 MAC 1. All rights reserved.
//

#import "ViewController.h"
#import "RequestModel.h"

#import "ModelResponse.h"

#import "ModelResponse.h"
#import "Categorias.h"

#import "DescriptionCategoryCellMain.h"
#define kBgQueue dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)
#import "SDWebImage/UIImageView+WebCache.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize respuesta;
@synthesize tableView;
@synthesize respuestaImgAtribut;

@synthesize respuestaParserMain;
@synthesize urlNew;
@synthesize diccAPassar;

@synthesize tesImage;


- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.respuesta =[[NSMutableArray alloc] init];// inicializamos array mutable respuesta
    self.respuestaImgAtribut=[[NSMutableArray alloc] init];
   self.respuestaParserMain=[[NSMutableArray alloc]init];
    
    self.diccAPassar=[[NSDictionary alloc] init];
    tableView.delegate = self;
    tableView.dataSource = self;
    
    //LLamo el WS 
    self.llamarWS = [[GestorWebServices alloc]init];//inicializamos WebServices
   RequestModel  *request = [[RequestModel alloc]init];//Request
    request.dataJson = nil;
    NSError *error = nil;
    NSData *jsonResponse=[self.llamarWS llamaWS:request];
    
    
    
    
    NSDictionary *dicRes = [NSJSONSerialization JSONObjectWithData:jsonResponse options:NSJSONReadingMutableContainers error:&error];
  // NSLog(@"%@",dicRes);
  
    NSDictionary *feed=[dicRes valueForKey:@"feed"];
    NSDictionary *entry=[feed valueForKey:@"entry"];//
      //   NSLog(@"Entry   %@",entry);
   
    NSArray *summary=[entry valueForKey:@"summary"];
                NSString *labelSumary=[summary valueForKey:@"label"];
            ///   NSLog(@"Sumary %@",labelSumary);
        NSArray *rights=[entry valueForKey:@"rights"];
                NSString *labelRigths=[rights valueForKey:@"label"];
        NSDictionary *category=[entry valueForKey:@"category"];
            NSArray *atributesCategory=[category valueForKey:@"attributes"];
           NSLog(@"cate %@",atributesCategory);
    
    
    
    
    /*
            ModelResponse *response = [[ModelResponse alloc]init];//response
            response.categoriaAtributes=[NSArray arrayWithArray:atributesCategory];

    

    
    for (NSArray *catAtributes in response.categoriaAtributes ) {
        ModelResponse *response = [[ModelResponse alloc]init];//response
        response.label=[catAtributes valueForKey:@"label"];
        response.imid=[catAtributes valueForKey:@"im:id"];
        response.scheme=[catAtributes valueForKey:@"scheme"];
        response.term=[catAtributes valueForKey:@"term"];
        
        //NSLog(@"Respuesta sheme %@ ",[catAtributes valueForKey:@"scheme"]);

        [self.respuesta addObject:response];
        
    }
        NSArray *im_image=[entry valueForKey:@"im:image"];
   // NSLog(@"%@",im_image);
    
    NSMutableArray *stringUrls = [[NSMutableArray alloc] init];
    int i=0;
    for (NSString  *datosURLimgs  in im_image) {
     //   NSLog(@"OK %@",[[datosURLimgs valueForKey:@"label"] objectAtIndex:i]);
       
            ModelResponse *response = [[ModelResponse alloc]init];//response
            response.labelUrlImg=[[datosURLimgs valueForKey:@"label"] objectAtIndex:i];
        [self.respuestaImgAtribut addObject:response];

        i++;

    }
    for (NSArray *imagenes in im_image ) {
        ModelResponse *response = [[ModelResponse alloc]init];//response
        NSDictionary *atrributes=[imagenes valueForKey:@"attributes"];
            response.labelHeigt = [atrributes valueForKey:@"height"];
            response.labelUrlImg=[imagenes valueForKey:@"label"];
        [self.respuestaImgAtribut addObject:response];
    }
    
    
    
    */
    
    NSLog(@"%lu",(unsigned long)[self.respuestaImgAtribut count]);
    NSLog(@"%lu",(unsigned long)[self.respuesta count]);

    
    
    
    //------------------Autor
    /*
            NSDictionary *autor=[feed valueForKey:@"author"];
                NSDictionary *name=[autor valueForKey:@"name"];
                NSString *label=[name valueForKey:@"label"];
                 NSLog(@"%@",label);

            NSArray *uri=[autor valueForKey:@"uri"];
                NSString *label2=[uri valueForKey:@"label"];
              NSLog(@"%@",label2);
    
    */
 
    
  //  NSLog(@"Respuesta Categorias ");
//    NSLog(@"Respuesta Imagenes Descripcion");
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma Set Table data Source


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return self.respuesta.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"Cell";
    
    
    DescriptionCategoryCellMain *cell = (DescriptionCategoryCellMain *)[self.tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
 
    // Configure the cell...
    if (cell == nil) {
        cell = [[DescriptionCategoryCellMain alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
    }
    
    
    ModelResponse *response = [[ModelResponse alloc]init];//response
    ModelResponse *response2 = [[ModelResponse alloc]init];//response

    if (self.respuesta != nil ) {
     /*
        response=[self.respuesta objectAtIndex:indexPath.row];
        response2=[self.respuestaImgAtribut objectAtIndex:indexPath.row];
        cell.lblId.text = response.imid;
        cell.lblsheme.text = response.scheme;
        cell.lblLblName.text = response.label;
        cell.lblLblTerm.text = response.term;
        
        */
        
     //   NSLog(@"%@",response2.labelUrlImg);
        
        // Here we use the new provided sd_setImageWithURL: method to load the web image
        [cell.iconoBase sd_setImageWithURL:[NSURL URLWithString:response2.labelUrlImg]
                          placeholderImage:[UIImage imageNamed:@"placeholder.png"]];
    }
   

    return cell;
    
}
/*
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{

    return @"Category";
}*/

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"Current Selectedx %ld",(long)indexPath.row);
 //   self.diccAPassar =[self.respuesta objectAtIndex:indexPath.row];
   //   NSLog(@"Diccionario %@ ",diccAPassar);
  /*
    NSString * storyboardName = @"Main";
    NSString * viewControllerID = @"Categoria";
    UIStoryboard * storyboard = [UIStoryboard storyboardWithName:storyboardName bundle:nil];
    UIViewController * controller = (UIViewController *)[storyboard instantiateViewControllerWithIdentifier:viewControllerID];
    [self presentViewController:controller animated:NO completion:nil];
    [self performSegueWithIdentifier:@"Categoria" sender:nil];
*//*
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    Categorias *mandadDatos= [[Categorias alloc] init];
    ModelResponse *response = [[ModelResponse alloc]init];//response
    response=[self.respuesta objectAtIndex:indexPath.row];
    mandadDatos.urlNewRequest=response.scheme;
    [self.navigationController showViewController:mandadDatos sender:self];
    */
 //   [self presentViewController:secondScreen animated:YES completion:nil];

    
    
    
    // NSDictionary *dicCuentas =[dic valueForKey:stringCuentas];
 //   CategoriaViewController *mandarDatos=[[CategoriaViewController alloc] init];
   // mandarDatos.datosPassed=[[NSMutableArray alloc] initWithArray:[self.respuesta objectAtIndex:indexPath.row]];
}




-(NSArray *)parserDatos:(NSArray *)datosCompletos{
    
    self.respuestaParserMain= [[NSMutableArray alloc]init];
    
    ModelResponse *response = [[ModelResponse alloc]init];//response
    int aux=0;
    for (NSArray *catAtributes in datosCompletos ) {
    /*    response.label=[catAtributes valueForKey:@"label"];
        response.imid=[catAtributes valueForKey:@"im:id"];
        response.scheme=[catAtributes valueForKey:@"scheme"];
        response.term=[catAtributes valueForKey:@"term"];
       */
        //NSLog(@"%@-----",response.scheme);
        [self.respuesta addObject:response];
         aux++;
    }
    //    NSLog(@"%@-----",cuentasObjCredito);
    return self.respuestaParserMain;
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    Categorias *mandarDatos = segue.destinationViewController;
    if ([segue.identifier isEqualToString:@"Categoria"]) {
        
        ModelResponse *response = [[ModelResponse alloc]init];//response
        ModelResponse *response2 = [[ModelResponse alloc]init];//response

        NSLog(@"Categoria");
        NSIndexPath *indexPath = [self.tableView indexPathForSelectedRow];
        
        self.urlNew=[respuestaImgAtribut objectAtIndex:indexPath.row];
        NSLog(@"URL SHEEME %@",self.urlNew);

        response=[respuestaImgAtribut objectAtIndex:indexPath.row];
        response2=[respuesta objectAtIndex:indexPath.row];

        response=[respuesta objectAtIndex:indexPath.row];
    /*    NSLog(@" IIS  %@",response.imid);
        NSLog(@"LABEL %@",response.label);
        NSLog(@"URL SHEEME %@",response.scheme);
        NSLog(@"TERM %@",response.term);
        */
        mandarDatos.urlNewRequest=self->urlNew;
        mandarDatos.datosPassed= [respuesta objectAtIndex:indexPath.row];
    }
    
}



@end
