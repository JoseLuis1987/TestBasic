//
//  AppDelegate.h
//  Test
//
//  Created by MAC 1 on 14/04/16.
//  Copyright © 2016 MAC 1. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

