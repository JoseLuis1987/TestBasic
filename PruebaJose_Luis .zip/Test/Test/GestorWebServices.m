//
//  GestorWS.m
//  Test
//
//  Created by MAC 1 on 14/04/16.
//  Copyright © 2016 MAC 1. All rights reserved.
//

#import "GestorWebServices.h"

@implementation GestorWebServices
static  GestorWebServices *_gestorServiciosWeb=nil;
static NSString *modoConexion=@"Conexion";

@synthesize tipoOperacion=_tipoOperacion;
@synthesize respuestaWS=_respuestaWS;
@synthesize internetReachable=_internetReachable;
@synthesize datosCompletos=_datosCompletos;
@synthesize respuestaWSoth=_respuestaWSoth;

#pragma mark -Estatus de la conexion

#pragma mark -Inicializador
-(id)init{
    self=[super init];
    if(self)
    {
        self.tipoOperacion = 0;
      
    }
    
    return self;
}

#pragma mark -Estatus de la conexion

-(NSInteger) checkNetworkStatus{
    
    _internetReachable = [Reachability reachabilityForInternetConnection];
    NetworkStatus internetStatus = [_internetReachable currentReachabilityStatus];
    switch (internetStatus)
    {
        case NotReachable:
        {
            //    //NSLog(@"Internet abajo.");
            _internet = 0;
            /*
             UIAlertView *message = [[UIAlertView alloc] initWithTitle:@"Error de conexiòn a internet verifica o  intenta mas tarde "
             message:@"No hay conexiòn con el servidor intente mas tarde. "
             delegate:nil
             cancelButtonTitle:@"OK"
             otherButtonTitles:nil];
             
             [message show];*/
            
            break;
        }
        case ReachableViaWiFi:
        {
            //   //NSLog(@"Internet trabajando por wifi.");
            _internet = 1;
            break;
        }
        case ReachableViaWWAN:
        {
            //    //NSLog(@"Internet trabajando por WWAN.");
            _internet = 1;
            break;
        }
    }
    return _internet;
}

#pragma mark -Singleton
+gestor
{
    
    if(_gestorServiciosWeb==nil)
    {
        _gestorServiciosWeb=[[GestorWebServices alloc] init];
    }
    return _gestorServiciosWeb;
}


-(NSData*)llamaWS:(RequestModel *)request{
    self.tipoOperacion=1;
    
    [self callWScontent];
        return _respuestaWS;
}

-(NSData*)llamaWSOth:(NSString *)newShemaUrl{

    self.tipoOperacion=2;
    [self callWScontent2:newShemaUrl];
    return _respuestaWSoth;
}



#pragma mark -Salir de Espera

-(void)terminoTimeout
{
    self.hayEventosWS = NO;
    [self.delegate falloGestorWebServices:self];
}

#pragma mark -Metodo de Espera

- (BOOL)dormirEsperandoDatos {
    
    /* return dispatch_semaphore_wait(hayDatos,DISPATCH_TIME_FOREVER)==0;*/
    //NSAssert([NSThread isMainThread], @"Method called using a thread other than main!");
    self.hayEventosWS=YES;
    // global
    NSRunLoop *theRL = [NSRunLoop currentRunLoop];
    
    NSTimer *timer=[NSTimer timerWithTimeInterval:30 target:self selector:@selector(terminoTimeout) userInfo:nil repeats:NO];
    
    [theRL addTimer:timer forMode:NSDefaultRunLoopMode];
    
    // NSLog(@"Empieza el Loop");
    while (self.hayEventosWS)
    {
        if(![theRL runMode:NSDefaultRunLoopMode beforeDate:[NSDate distantFuture]])
            break;
    }
    return YES;
    
}
- (BOOL)callWScontent2:(NSString*)newUrl{
   
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setURL:[NSURL URLWithString:newUrl]];
    [request setHTTPMethod:@"GET"];
    // [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    // [request setValue:@"application/json" forHTTPHeaderField:@"Accept"];
    // [request setHTTPBody:nil];
    //  [request setHTTPBody:stringBody];
    
    NSURLConnection *conexion=[[NSURLConnection alloc] initWithRequest:request delegate:self startImmediately:YES];
    //[conexion scheduleInRunLoop:[NSRunLoop currentRunLoop] forMode:modoConexion];
    [conexion start];
    
    BOOL resultadoEspera=YES;
    
    if(self.tipoOperacion != nil){
        resultadoEspera=[self dormirEsperandoDatos];
    }
    [conexion unscheduleFromRunLoop:[NSRunLoop currentRunLoop] forMode:modoConexion];
    
    return resultadoEspera;
    
}





- (BOOL)callWScontent{
    
    NSString *url = [NSString stringWithFormat:@"%@", NSLocalizedString(@"URL_WS", nil)];
 //   NSLog(@"%@",url);
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setURL:[NSURL URLWithString:url]];
    [request setHTTPMethod:@"GET"];
    // [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
   // [request setValue:@"application/json" forHTTPHeaderField:@"Accept"];
   // [request setHTTPBody:nil];
  //  [request setHTTPBody:stringBody];

    NSURLConnection *conexion=[[NSURLConnection alloc] initWithRequest:request delegate:self startImmediately:YES];
    //[conexion scheduleInRunLoop:[NSRunLoop currentRunLoop] forMode:modoConexion];
    [conexion start];
    
    BOOL resultadoEspera=YES;
    
    if(self.tipoOperacion != nil){
        resultadoEspera=[self dormirEsperandoDatos];
    }
    [conexion unscheduleFromRunLoop:[NSRunLoop currentRunLoop] forMode:modoConexion];
    
    return resultadoEspera;

}

- (void)downloadJSONFromURL {
    
    
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:NSLocalizedString(@"URL_WS", nil)]];
    [[NSURLConnection alloc] initWithRequest:request delegate:self];
    
    BOOL resultadoEspera =YES;
    
    if(self.tipoOperacion != nil){
        resultadoEspera=[self dormirEsperandoDatos];
    }
 //   [conexion unscheduleFromRunLoop:[NSRunLoop currentRunLoop] forMode:modoConexion];

}


#pragma mark -Conection Servidor


- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    
    NSString *datos = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
    
  // NSLog(@"Description %@",datos);
    
    [self.datosCompletos appendData:data];
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    
    self.datosCompletos = [[NSMutableData alloc] initWithLength:0];
    NSLog(@"Recibi respuesta");
}

-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    self.hayEventosWS = NO;
    [self.delegate terminoGestorWebServices:self];
    //[popup show];
}


- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    
    if (self.tipoOperacion == 1) {
        self.respuestaWS = [[NSData alloc]init];
        self.respuestaWS=self.datosCompletos;
    }
    if (self.tipoOperacion == 2) {
        self.respuestaWSoth = [[NSData alloc]init];
        self.respuestaWSoth=self.datosCompletos;
    }
    self.hayEventosWS=NO;
    [self.delegate terminoGestorWebServices:self];
    self.datosCompletos=nil;
}



@end
