//
//  MainViewMenu.h
//  Test
//
//  Created by MAC 1 on 18/04/16.
//  Copyright © 2016 MAC 1. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GestorWebServices.h"
@interface MainViewMenu : UIViewController<UITableViewDelegate,UITableViewDataSource>

@property (strong,nonatomic) GestorWebServices *llamarWS;
@property (strong,nonatomic) NSArray *tableData;
@property (strong,nonatomic) NSMutableArray *tableDataMutable;
@property (strong,nonatomic) NSDictionary *dicResult;


@property (weak, nonatomic) IBOutlet UITableView *tableView;
@end
