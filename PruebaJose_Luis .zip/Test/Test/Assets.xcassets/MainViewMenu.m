//
//  MainViewMenu.m
//  Test
//
//  Created by MAC 1 on 18/04/16.
//  Copyright © 2016 MAC 1. All rights reserved.
//

#import "MainViewMenu.h"
#import "ModelResponse.h"

#import "ListaAppsViewController.h"

#import "DescriptionCategoryCellMain.h"
#define kBgQueue dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)
#import "UIImageView+WebCache.h"

#define CON_CONEXION 1
@implementation MainViewMenu
@synthesize tableView;
@synthesize llamarWS;
@synthesize tableData;
@synthesize tableDataMutable;
@synthesize dicResult;

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //    Load IMG URL EXAMPLE
    /* [tesImage sd_setImageWithURL:[NSURL URLWithString:@"https://www.apple.com/global/elements/itunesmodule/twitter_icon.png"]
     placeholderImage:[UIImage imageNamed:@"placeholder.png"]
     completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
     }];
     */
    
    self.tableDataMutable= [[NSMutableArray alloc ] init];

    
    if (CON_CONEXION) {
        //LLamo el WS
        self.llamarWS = [[GestorWebServices alloc]init];//inicializamos WebServices
        RequestModel  *request = [[RequestModel alloc]init];//Request
        request.dataJson = nil;
        NSError *error = nil;
        NSData *jsonResponse=[self.llamarWS llamaWS:request];
       dicResult = [NSJSONSerialization JSONObjectWithData:jsonResponse options:NSJSONReadingMutableContainers error:&error];
     //   NSLog(@"%@",dicResult);
    }else{
        //LLamo el WS
        NSString *filePath = [[NSBundle mainBundle] pathForResource:@"jsonFile" ofType:@"json"];
        
        NSData *content = [[NSData alloc] initWithContentsOfFile:filePath];
        
        
       dicResult = [NSJSONSerialization JSONObjectWithData:content options:kNilOptions error:nil];
    }
  //   NSLog(@"%@",dicResult);
    
    NSDictionary *feed=[dicResult valueForKey:@"feed"];
    //NSLog(@"Entry   %@",feed);
    NSDictionary *entry=[feed valueForKey:@"entry"];//

    int aux=0;
    for (NSArray *datos in entry) {
        ModelResponse  *respuesta = [[ModelResponse alloc]init];//Request
        
         if (CON_CONEXION) {
             NSLog(@"Category %@",[datos valueForKey:@"category"]);

             respuesta.categoria=[datos valueForKey:@"category"];
             
         }
         else{
             NSLog(@"Category %@",[datos valueForKey:@"category"]);

             respuesta.categoria=(NSDictionary*)[datos valueForKey:@"category"];
         }
        respuesta.categoriaAtributes=[respuesta.categoria valueForKey:@"attributes"];
            respuesta.labelCategory=[respuesta.categoriaAtributes valueForKey:@"label"];
            respuesta.scheme=[respuesta.categoriaAtributes valueForKey:@"scheme"];
            respuesta.term=[respuesta.categoriaAtributes valueForKey:@"term"];
     //   NSLog(@"cate %@",respuesta.categoriaAtributes);
        
        respuesta.id_ID=[datos valueForKey:@"id"];
        respuesta.atributes_id=[respuesta.id_ID valueForKey:@"attributes"];
        respuesta.im_id=[respuesta.atributes_id valueForKey:@"im:id"];
        respuesta.bundle=[respuesta.atributes_id valueForKey:@"im:bundleId"];
        //  NSLog(@"id_ID %@",respuesta.id_ID);
        
       respuesta.im_artist=[datos valueForKey:@"im:artist"];
        respuesta.label_im_artist=[respuesta.im_artist valueForKey:@"label"];
          //NSLog(@"im:artist %@",respuesta.im_artist);
        
         respuesta.im_image=[entry valueForKey:@"im:image"];
            respuesta.atributes_Im_image =[respuesta.im_image valueForKey:@"attributes"];
                respuesta.image_labelheigth=[respuesta.atributes_Im_image valueForKey:@"height"];
        respuesta.label_im_image_icons=[respuesta.im_image valueForKey:@"label"];
            respuesta.label_im_image=[[respuesta.label_im_image_icons objectAtIndex:aux] objectAtIndex:0];

           // respuesta.label_im_image=[respuesta.label_im_image_icons objectAtIndex:0];
              //  NSLog(@"URL unic img %@",respuesta.label_im_image );
        
        
     //   NSLog(@"im:image atributes heigth %@",respuesta.image_labelheigth);
     //   NSLog(@"im:image label %@",respuesta.label_im_image);
        
        respuesta.price=[entry valueForKey:@"im:price"];
        respuesta.atributes_price=[respuesta.price valueForKey:@"attributes"];
        
        respuesta.amount=[[respuesta.atributes_price valueForKey:@"amount"] objectAtIndex:aux];
        respuesta.currency=[[respuesta.atributes_price valueForKey:@"currency"] objectAtIndex:aux];
       // NSLog(@"im:price %@ %@",respuesta.amount,respuesta.currency);
        
        
        respuesta.im_releaseDate=[entry valueForKey:@"im:releaseDate"];
        respuesta.im_releaseDate_atributes=[respuesta.im_releaseDate valueForKey:@"attributes"];
        respuesta.label_Date_atributes=[[respuesta.im_releaseDate_atributes valueForKey:@"label"] objectAtIndex:aux];
       // NSLog(@"im:releaseDate %@",respuesta.im_releaseDate);
       // NSLog(@"label_Date_atributes %@",respuesta.label_Date_atributes);
        respuesta.summary=[entry valueForKey:@"summary"];
        respuesta.labelSumary=[[ respuesta.summary valueForKey:@"label"] objectAtIndex:aux];
        //NSLog(@"Sumary %@", respuesta.labelSumary);

        
        respuesta.rights=[entry valueForKey:@"rights"];
       respuesta.labelRigths=[[respuesta.rights valueForKey:@"label"] objectAtIndex:aux];
       // NSLog(@"Rigths %@",respuesta.labelRigths);
        
        
        
        respuesta.im_name=[entry valueForKey:@"im:name"];
        respuesta.label_im_name=[[respuesta.im_name valueForKey:@"label"] objectAtIndex:aux] ;
    //    NSLog(@"name %@", respuesta.label_im_name);
        //im:name
        
        [tableDataMutable addObject:respuesta];
        aux++;
    }
    //NSLog(@"%@",tableDataMutable);
    

    // Initialize table data
    tableData =[[NSMutableArray alloc] init];

    tableView.delegate = self;
    tableView.dataSource = self;

    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [tableDataMutable count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"Cell";
    
    
    DescriptionCategoryCellMain *cell = (DescriptionCategoryCellMain *)[self.tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    
    // Configure the cell...
    if (cell == nil) {
        cell = [[DescriptionCategoryCellMain alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
    }
    
    NSDictionary *dicItemAapp=[tableDataMutable objectAtIndex:indexPath.row];
    
    NSDictionary *category=[[NSDictionary alloc] init];
    NSDictionary *atributes=[[NSDictionary alloc] init];
    NSString *nameCategory=[[NSString alloc] init];
    
    if (CON_CONEXION) {
        ModelResponse  *respuesta = [[ModelResponse alloc]init];//Request
        respuesta=[tableDataMutable objectAtIndex:indexPath.row];
       // NSLog(@"%@",respuesta.labelCategory);
       // NSLog(@"%@",respuesta.label_im_image);

        cell.lblLblName.text = [NSString stringWithFormat:@"%@",respuesta.labelCategory];
        cell.lblLblTerm.text=respuesta.labelRigths;
        
        [cell.iconoBase sd_setImageWithURL:[NSURL URLWithString:respuesta.label_im_image]
                          placeholderImage:[UIImage imageNamed:@"placeholder.png"]];
    }else{
        
        dicItemAapp=[tableDataMutable objectAtIndex:indexPath.row];
        category=[dicItemAapp valueForKey:@"category"];
        atributes=[category valueForKey:@"attributes"];
        nameCategory=[atributes valueForKey:@"label"];
        
        
    }
  
    
    
    
   // NSLog(@"%@",nameCategory);
    cell.textLabel.text =nameCategory;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"Current Selectedx %ld",(long)indexPath.row);
 /*
  UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    ListaAppsViewController *mandadDatos= [[ListaAppsViewController alloc] init];
 
    ModelResponse *response = [[ModelResponse alloc]init];//response
    mandadDatos.appArrayPassed=[tableDataMutable objectAtIndex:indexPath.row];
 
    [self.navigationController presentViewController:mandadDatos animated:YES completion:nil];*/
    //[self.navigationController showViewController:mandadDatos sender:self];
    /*
    NSString * storyboardName = @"Main";
    NSString * viewControllerID = @"ListaApps";
    ListaAppsViewController *mandadDatos= [[ListaAppsViewController alloc] init];
    mandadDatos.appArrayPassed=[tableDataMutable objectAtIndex:indexPath.row];

    UIStoryboard * storyboard = [UIStoryboard storyboardWithName:storyboardName bundle:nil];
    UIViewController * controller = (UIViewController *)[storyboard instantiateViewControllerWithIdentifier:viewControllerID];
    [self presentViewController:controller animated:NO completion:nil];
    [self performSegueWithIdentifier:@"Detalle" sender:nil];*/
    
    [self performSegueWithIdentifier:@"Detalle" sender:nil];

}

#pragma Segue

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    ListaAppsViewController *mandarDatos = segue.destinationViewController;
    if ([segue.identifier isEqualToString:@"Detalle"]) {
        NSLog(@"Detalle Apss %@",[self.tableView indexPathForSelectedRow]);
        NSIndexPath *indexPath = [self.tableView indexPathForSelectedRow];
        mandarDatos.appArrayPassed=[tableDataMutable objectAtIndex:indexPath.row];
    }
}


@end
