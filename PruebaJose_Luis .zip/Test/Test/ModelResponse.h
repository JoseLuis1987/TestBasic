//
//  ModelResponse.h
//  Test
//
//  Created by MAC 1 on 14/04/16.
//  Copyright © 2016 MAC 1. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ModelResponse : NSObject

@property(nonatomic,strong) NSArray * feed;
@property(nonatomic,strong) NSDictionary * autor;
@property(nonatomic,strong) NSDictionary * entry;
@property(nonatomic,strong) NSDictionary * categoria;
@property(nonatomic,strong) NSArray * categoriaAtributes;
        @property(nonatomic,strong) NSString * labelCategory;
        @property(nonatomic,strong) NSString * scheme;
        @property(nonatomic,strong) NSString * term;


//array
@property(nonatomic,strong) NSArray *id_ID;
    @property(nonatomic,strong) NSDictionary * atributes_id;
        @property(nonatomic,strong) NSString * bundle;
        @property(nonatomic,strong) NSString * im_id;
    @property(nonatomic,strong) NSString * label_id;


@property(nonatomic,strong) NSArray *im_artist;
    @property(nonatomic,strong) NSString * label_im_artist;




@property(nonatomic,strong) NSDictionary *im_image;
    @property(nonatomic,strong) NSArray *atributes_Im_image;
    @property(nonatomic,strong) NSString *image_labelheigth;
@property(nonatomic,strong) NSArray *label_im_image_icons;

    @property(nonatomic,strong) NSString *label_im_image;


@property(nonatomic,strong) NSArray *price;
    @property(nonatomic,strong) NSArray *atributes_price;
        @property(nonatomic,strong) NSString *amount;
        @property(nonatomic,strong) NSString *currency;

@property(nonatomic,strong) NSArray *im_releaseDate;
    @property(nonatomic,strong) NSArray *im_releaseDate_atributes;
        @property(nonatomic,strong) NSString * label_Date_atributes;


@property(nonatomic,strong) NSArray *summary;
    @property(nonatomic,strong) NSString *labelSumary;


@property(nonatomic,strong) NSArray *rights;
    @property(nonatomic,strong) NSString *labelRigths;

//-.-----------------------------------------------------

@property(nonatomic,strong) NSArray *im_name;
@property(nonatomic,strong) NSString *label_im_name;


//@property(nonatomic,strong) NSString * imid;
   /// @property(nonatomic,strong) NSString * imid;
      @property(nonatomic,strong) NSString * labelUrlImg;
    @property(nonatomic,strong) NSString * labelHeigt;



@property(nonatomic,strong) NSString *title;
@property(nonatomic,strong) NSDictionary *image;




/*
 
@property(nonatomic,strong) NSData * dataJson;
@property(nonatomic,strong) NSData * dataJson;
@property(nonatomic,strong) NSData * dataJson;
@property(nonatomic,strong) NSData * dataJson;
@property(nonatomic,strong) NSData * dataJson;
@property(nonatomic,strong) NSData * dataJson;
@property(nonatomic,strong) NSData * dataJson;
@property(nonatomic,strong) NSData * dataJson;
@property(nonatomic,strong) NSData * dataJson;
@property(nonatomic,strong) NSData * dataJson;
@property(nonatomic,strong) NSData * dataJson;
@property(nonatomic,strong) NSData * dataJson;
*/
@end
