//
//  DescriptionCategoryCellMain.m
//  Test
//
//  Created by MAC 1 on 18/04/16.
//  Copyright © 2016 MAC 1. All rights reserved.
//

#import "CellAppDetalleApp.h"

@implementation CellAppDetalleApp

@synthesize lbldate;
@synthesize lblLblArtist;
@synthesize lblLblName;
@synthesize lblRigths;
@synthesize iconoBase;
@synthesize lblsumary;
@synthesize lblid;
@synthesize lbl_price;
@synthesize lbl_date;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}


@end
