//
//  Categorias.h
//  Test
//
//  Created by MAC 1 on 18/04/16.
//  Copyright © 2016 MAC 1. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GestorWebServices.h"
@interface Categorias : UIViewController
@property (strong, nonatomic) NSMutableArray * datosPassed;

@property (strong, nonatomic) NSMutableArray * datosTable;

//@property (strong, nonatomic) NSString * urlNewRequest;
@property (nonatomic, strong) NSString *nombre;
@property (nonatomic, strong) NSString *urlNewRequest;

@property (strong,nonatomic) GestorWebServices *llamarWS;
@property (weak, nonatomic) IBOutlet UILabel *lbl_idCategoria;
@property (weak, nonatomic) IBOutlet UILabel *lbl_TipoCategoria;

@property (strong, nonatomic) NSMutableArray * datosParsed;


@end
