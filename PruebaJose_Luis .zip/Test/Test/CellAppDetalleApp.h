//
//  DescriptionCategoryCellMain.h
//  Test
//
//  Created by MAC 1 on 18/04/16.
//  Copyright © 2016 MAC 1. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellAppDetalleApp : UITableViewCell
@property(strong,nonatomic)IBOutlet UILabel *lblRigths;
@property(strong,nonatomic)IBOutlet UILabel *lbldate;
@property(strong,nonatomic)IBOutlet UILabel *lblLblName;
@property(strong,nonatomic)IBOutlet UILabel *lblLblArtist;
@property(strong, nonatomic)IBOutlet UIImageView *iconoBase;


@property(strong, nonatomic)IBOutlet UILabel *lblsumary;
@property(strong, nonatomic)IBOutlet UILabel *lblid;
@property(strong, nonatomic)IBOutlet UILabel *lbl_price;
@property(strong, nonatomic)IBOutlet UILabel *lbl_date;




/*

NSDictionary *category=[entry valueForKey:@"category"];
NSArray *atributesCategory=[category valueForKey:@"attributes"];
NSLog(@"cate %@",atributesCategory);

NSArray *id_ID=[entry valueForKey:@"id"];
NSLog(@"id_ID %@",id_ID);

NSArray *im_artist=[entry valueForKey:@"im:artist"];
NSLog(@"im:artist %@",im_artist);


NSDictionary *im_image=[entry valueForKey:@"im:image"];
NSArray *atributes_Im_image=[im_image valueForKey:@"attributes"];
NSString *labelImage=[atributes_Im_image valueForKey:@"attributes"];
NSLog(@"im:image atributes %@",atributes_Im_image);
NSLog(@"im:image label %@",labelImage);

NSArray *price=[entry valueForKey:@"im:price"];
NSLog(@"im:price %@",price);

NSArray *im_releaseDate=[entry valueForKey:@"im:releaseDate"];
NSLog(@"im:releaseDate %@",im_releaseDate);

NSArray *summary=[entry valueForKey:@"summary"];
NSString *labelSumary=[summary valueForKey:@"label"];
NSLog(@"Sumary %@",labelSumary);
NSArray *rights=[entry valueForKey:@"rights"];
NSString *labelRigths=[rights valueForKey:@"label"];
NSLog(@"Rigths %@",labelRigths);*/


@end
