//
//  ListaAppsViewController.m
//  Test
//
//  Created by Jose Luis on 18/04/16.
//  Copyright © 2016 MAC 1. All rights reserved.
//

#import "ListaAppsViewController.h"
#import "CellAppDetalleApp.h"
#include "ModelResponse.h"

#define kBgQueue dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)
#import "SDWebImage/UIImageView+WebCache.h"


@interface ListaAppsViewController ()

@end

@implementation ListaAppsViewController
@synthesize appArrayPassed;
@synthesize tableData;
@synthesize tableView;

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"Passed %@",appArrayPassed);
    
    
    // Initialize table data
    tableData =[[NSMutableArray alloc] init];
    
    tableView.delegate = self;
    tableView.dataSource = self;
    [tableData addObject:appArrayPassed];
    
    NSLog(@"Count %lu",(unsigned long)tableData.count);

    // Do any additional setup after loading the view.
    
   // NSDictionary *feed=[appArrayPassed valueForKey:@"feed"];
   // NSDictionary *entry=[feed valueForKey:@"entry"];//
    //   NSLog(@"Entry   %@",entry);
    /*
    NSArray *summary=[appArrayPassed valueForKey:@"summary"];
    NSString *labelSumary=[summary valueForKey:@"label"];
    ///   NSLog(@"Sumary %@",labelSumary);
    NSArray *rights=[appArrayPassed valueForKey:@"rights"];
    NSString *labelRigths=[rights valueForKey:@"label"];
    NSDictionary *category=[appArrayPassed valueForKey:@"category"];
    NSArray *atributesCategory=[category valueForKey:@"attributes"];
    NSLog(@"cate %@",atributesCategory);
*/
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewDidAppear:(BOOL)animated{
    NSLog(@"Will appear %@",appArrayPassed);
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
   
    return tableData.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"Cell";
    
    
    CellAppDetalleApp *cell = (CellAppDetalleApp *)[self.tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    
    // Configure the cell...
    if (cell == nil) {
        cell = [[CellAppDetalleApp alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
    }
    
    
    ModelResponse  *response = [[ModelResponse alloc]init];//Request
    response=[tableData objectAtIndex:indexPath.row];
    
  
  //  NSLog(@"%@,%@,%@,%@,%@,%@,%@,%@",response.label_Date_atributes,response.labelCategory,response.label_im_artist,response.labelSumary,response.im_id,response.amount,response.term,response.labelRigths);
    
    cell.lblRigths.text=response.label_im_name;
  cell.lbldate.text=response.label_Date_atributes;
   cell.lblLblName.text=response.labelCategory;
   cell.lblLblArtist.text=response.label_im_artist;
    cell.lblsumary.text= response.labelSumary;
    cell.lblid.text=response.im_id;
    cell.lbl_price.text=response.amount;
      cell.lbl_date.text=response.term;

    // Here we use the new provided sd_setImageWithURL: method to load the web image
    NSLog(@"%@",response.label_im_image);
    [cell.iconoBase sd_setImageWithURL:[NSURL URLWithString:response.label_im_image]
                      placeholderImage:[UIImage imageNamed:@"placeholder.png"]];
    // NSLog(@"%@",nameCategory);
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"Current Selectedx %ld",(long)indexPath.row);
    /*
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    ListaAppsViewController *mandadDatos= [[ListaAppsViewController alloc] init];
    ModelResponse *response = [[ModelResponse alloc]init];//response
    mandadDatos.appArrayPassed=[tableDataMutable objectAtIndex:indexPath.row];
    [self.navigationController showViewController:mandadDatos sender:self];*/
}

#pragma Segue

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    /*
    ListaAppsViewController *mandarDatos = segue.destinationViewController;
    if ([segue.identifier isEqualToString:@"showDetailApps"]) {
        NSLog(@"Detalle Apss %@",[self.tableView indexPathForSelectedRow]);
        NSIndexPath *indexPath = [self.tableView indexPathForSelectedRow];
        mandarDatos.appArrayPassed=[tableDataMutable objectAtIndex:indexPath.row];
    }*/
}




@end
