//
//  DescriptionCategoryCellMain.h
//  Test
//
//  Created by MAC 1 on 18/04/16.
//  Copyright © 2016 MAC 1. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DescriptionCategoryCellMain : UITableViewCell
@property(strong,nonatomic)IBOutlet UILabel *lblId;
@property(strong,nonatomic)IBOutlet UILabel *lblsheme;
@property(strong,nonatomic)IBOutlet UILabel *lblLblName;
@property(strong,nonatomic)IBOutlet UILabel *lblLblTerm;
@property(strong, nonatomic)IBOutlet UIImageView *iconoBase;

@end
