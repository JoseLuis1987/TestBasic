//
//  RequestModel.m
//  Test
//
//  Created by MAC 1 on 14/04/16.
//  Copyright © 2016 MAC 1. All rights reserved.
//

#import "RequestModel.h"

@implementation RequestModel
@synthesize dataJson;
@end
