//
//  GestorWS.h
//  Test
//
//  Created by MAC 1 on 14/04/16.
//  Copyright © 2016 MAC 1. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Reachability.h"
#import "RequestModel.h"
@class GestorWebServices;
@protocol GestorWebServicesDelegate <NSObject>

-(void)terminoGestorWebServices:(GestorWebServices*)gestor;
-(void)falloGestorWebServices:(GestorWebServices*)gestor;
@end
@interface GestorWebServices : NSObject <NSURLConnectionDelegate>
{
    dispatch_queue_t colaConexion;
    dispatch_semaphore_t hayDatos;
    
}
@property(strong,nonatomic)NSMutableData *datosCompletos;//RespuestaServidorData

/// REACHIBILITY

@property (strong,nonatomic) Reachability* internetReachable;
@property (strong,nonatomic) Reachability* hostReachable;
@property (assign,nonatomic) NSInteger internet;

@property(assign,nonatomic)BOOL hayEventosWS;

@property(assign,nonatomic)NSInteger tipoOperacion;
@property(strong,nonatomic)NSString *urlWebService;

@property(strong,nonatomic)NSData * respuestaWS;//Respuesta dela peticion de Servidor
@property(strong,nonatomic)NSData * respuestaWSoth;//Respuesta dela peticion de WS


-(NSData*)llamaWS:(RequestModel*)request;
-(NSData*)llamaWSOth:(NSString *)newShemaUrl;

-(NSInteger) checkNetworkStatus;
@property (weak,nonatomic) id <GestorWebServicesDelegate>delegate;
-(id)init;

//Request Universal
- (BOOL)ejecutarWSJSONFormat:(NSString *)pathWS content:(NSMutableString *)content;

- (BOOL)dormirEsperandoDatos;
- (BOOL)callWScontent;
-(void)terminoTimeout;
@end