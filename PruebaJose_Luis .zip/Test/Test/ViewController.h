//
//  ViewController.h
//  Test
//
//  Created by MAC 1 on 14/04/16.
//  Copyright © 2016 MAC 1. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GestorWebServices.h"



@interface ViewController : UIViewController <UITableViewDataSource,UITableViewDelegate>
@property (strong,nonatomic) GestorWebServices *llamarWS;
@property (weak, nonatomic) IBOutlet UIImageView *tesImage;

@property (strong,nonatomic) NSMutableArray *diccAPassar;
@property (strong,nonatomic) NSString *urlNew;

@property (strong,nonatomic) NSMutableArray *respuesta;
@property (strong,nonatomic) NSMutableArray *respuestaParserMain;


@property (strong,nonatomic) NSMutableArray *respuestaImgAtribut;

@property (weak, nonatomic) IBOutlet UITableView *tableView;



@property (strong,nonatomic) NSMutableArray *imagenesCategorias;


@end

