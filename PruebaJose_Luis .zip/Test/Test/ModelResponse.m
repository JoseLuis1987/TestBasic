//
//  ModelResponse.m
//  Test
//
//  Created by MAC 1 on 14/04/16.
//  Copyright © 2016 MAC 1. All rights reserved.
//

#import "ModelResponse.h"

@implementation ModelResponse
@synthesize feed;
@synthesize categoria;
    @synthesize categoriaAtributes;
    @synthesize scheme;
    @synthesize term;

@synthesize labelUrlImg;
@synthesize labelHeigt;


@synthesize id_ID;
@synthesize atributes_id;

@synthesize bundle;
@synthesize im_id;
@synthesize label_id;


@synthesize im_artist;
@synthesize label_im_artist;

@synthesize im_image;
@synthesize atributes_Im_image;
@synthesize image_labelheigth;
@synthesize label_im_image;
@synthesize label_im_image_icons;


@synthesize price;
@synthesize atributes_price;

@synthesize amount;
@synthesize currency;

@synthesize im_releaseDate;
@synthesize im_releaseDate_atributes;
@synthesize label_Date_atributes;


@synthesize summary;
@synthesize labelSumary;

@synthesize rights;
@synthesize labelRigths;

@synthesize im_name;
@synthesize label_im_name;
@end
