//
//  RequestModel.h
//  Test
//
//  Created by MAC 1 on 14/04/16.
//  Copyright © 2016 MAC 1. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RequestModel : NSObject
@property(nonatomic,strong) NSData * dataJson;
@end
