//
//  Categorias.m
//  Test
//
//  Created by MAC 1 on 18/04/16.
//  Copyright © 2016 MAC 1. All rights reserved.
//

#import "Categorias.h"
#import "ModelResponse.h"
@interface Categorias ()

@end

@implementation Categorias

@synthesize datosPassed;
@synthesize urlNewRequest;
@synthesize datosParsed=_datosParsed;
@synthesize lbl_idCategoria,lbl_TipoCategoria;

@synthesize llamarWS;


- (void)viewDidLoad {
    [super viewDidLoad];
    
   // NSLog(@"Passed %@",self.datosPassed);
   // NSLog(@"URL %@",self.urlNewRequest);
    
    [self initValuesMain];//carga valores 
    
    NSLog(@"Respuesta JSOM ",[self llamaWS ]);//LLamaWS
   
    
    
}
-(void)initValuesMain{
    ModelResponse  *response = [[ModelResponse alloc]init];//Request
    response = self.datosPassed;
    //self.lbl_TipoCategoria.text=response.label;
   // self.lbl_idCategoria.text=response.imid;
    NSLog(@"Nueva %@",response.scheme);
}

-(NSDictionary*)llamaWS
{
    //LLamo el WS
    self.llamarWS = [[GestorWebServices alloc]init];//inicializamos WebServices
    NSError *error = nil;
    ModelResponse  *response = [[ModelResponse alloc]init];//Request
    response = self.datosPassed;
    NSData *jsonResponse=[self.llamarWS llamaWSOth:response.scheme];
     NSDictionary *dicRes = [NSJSONSerialization JSONObjectWithData:jsonResponse options:NSJSONReadingMutableContainers error:&error];
    NSLog(@"REsult Dic  %@",dicRes);

    return dicRes;
}



/*
-(NSMutableArray*)parserResultJson:(NSDictionary*)diccionarioAParsear{
    
    //LLamo el WS
    self.llamarWS = [[GestorWebServices alloc]init];//inicializamos WebServices
    NSError *error = nil;
    
    ModelResponse  *response = [[ModelResponse alloc]init];//Request
    
    response = self.urlNewRequest;
    
    
    NSData *jsonResponse=[self.llamarWS llamaWSOth:self.urlNewRequest];
    NSDictionary *dicRes = [NSJSONSerialization JSONObjectWithData:jsonResponse options:NSJSONReadingMutableContainers error:&error];
    NSLog(@"REsult Dic  %@",dicRes);
    

    
    
    
    return _datosParsed;
}
*/

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)viewWillAppear:(BOOL)animated{

    NSLog(@"Passed %@",self.datosPassed);
    NSLog(@"URL %@",self.urlNewRequest);
    
}


-(IBAction)backAction:(id)sender{
    
    NSLog(@"Regresar");
}
@end
