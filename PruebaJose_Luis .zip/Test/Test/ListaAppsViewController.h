//
//  ListaAppsViewController.h
//  Test
//
//  Created by Jose Luis on 18/04/16.
//  Copyright © 2016 MAC 1. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ListaAppsViewController : UIViewController <UITableViewDataSource,UITableViewDelegate>
{

}
@property (strong, nonatomic) NSMutableArray * appArrayPassed;
@property (strong,nonatomic) NSMutableArray *tableData;
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end
